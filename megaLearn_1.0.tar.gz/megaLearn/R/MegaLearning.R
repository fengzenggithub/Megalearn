MegaLearning <-
function(x,y, method = NULL, 
                      methodslist=NULL,
                      rfntree = 500, rfmtry = NULL,
                      svmkernel = "linear", svmscale = FALSE,
                      adamfinal = 100,
                      glmnetalpha = 0.9, glmnetfamily = "multinomial", glmnetstandardize = FALSE,
                      knnk = 1,
                      pcatol = 0.2, pcascale = FALSE, pcacenter = FALSE,
                      nnetsize = 5, nnetrang = 0.1, nnetdecay = 0.1, nnetMaxNWts = 5000, nnetlinout = FALSE, 
                      nblap = 1,
                      split_ratio=0.25,
                      seed=164000082,
                      weight=NULL){
  split=split_data(x,y,split_ratio,weight=weight,seed=seed)
  
  xtrain=split$xtrain
  xtest=split$xtest
  ytrain=split$ytrain
  ytest=split$ytest
  
  acc = 0
  if (!is.null(method)){
    model=train_model(xtrain,ytrain,xtest,ytest,algorithm=method, 
                      rfntree = rfntree, rfmtry = rfmtry,
                      svmkernel = svmkernel, svmscale = svmscale,
                      adamfinal = adamfinal,
                      glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                      knnk =knnk,
                      pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                      nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                      nblap=nblap,
                      seed=seed)
    acc = model$accuracy
  }
  
  if(!is.null(methodslist)){
    models=train_models(xtrain,ytrain,xtest,ytest,methodslist=methodslist, acc = acc, method = method, 
                        rfntree = rfntree, rfmtry = rfmtry,
                        svmkernel = svmkernel, svmscale = svmscale,
                        adamfinal = adamfinal,
                        glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                        knnk =knnk,
                        pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                        nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                        nblap=nblap,
                        seed=seed)
    df3<-as.vector(unlist(models$result))
    names(df3)=methodslist
  }
  
  if (!is.null(method) & !is.null(methodslist)){
    MegaResult=list("method_accuracy"=model, "methods_accuracy"=df3)
  }
  else if (!is.null(method) & is.null(methodslist)){
    MegaResult=list("method_accuracy"=model)
  }
  else if(is.null(method) & !is.null(methodslist)){
    MegaResult=list("methods_accuracy"=df3)
  }
  else{
    stop("Error: no classifier specified")
  }
  return(MegaResult)
}
