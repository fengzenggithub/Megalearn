weight <-
function(pvalues){
  library(qvalue)
  pvs = pvalues
  pvs=pvs[which(pvs>1)]=1
  pvs[which(pvs<0)]=0
  qvs=qvalue(pvs)
  qvs[which(qvs>1)]=1
  w = -log(qvs)
  return(w)
}
