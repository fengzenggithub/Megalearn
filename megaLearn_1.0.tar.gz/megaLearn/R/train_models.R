train_models <-
function(xtrain,ytrain,xtest,ytest, methodslist = NULL, acc, method = NULL, 
                         rfntree, rfmtry,
                         svmkernel , svmscale,
                         adamfinal,
                         glmnetalpha, glmnetfamily, glmnetstandardize ,
                         knnk,
                         pcatol, pcascale, pcacenter,
                         nnetsize, nnetrang, nnetdecay, nnetMaxNWts, nnetlinout, 
                         nblap,
                         seed) {
  result = list()
  
  for (algo in methodslist) {
    if (!is.null(method)){
      if (algo == method){
        result[[algo]] = acc
      }
      else{
        model = train_model(xtrain,ytrain,xtest,ytest,algo,
                            rfntree = rfntree, rfmtry = rfmtry,
                            svmkernel = svmkernel, svmscale = svmscale,
                            adamfinal = adamfinal,
                            glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                            knnk =knnk,
                            pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                            nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                            nblap=nblap,
                            seed=seed)
        result[[algo]] = model$accuracy
      }
    }
    else{
      model = train_model(xtrain,ytrain,xtest,ytest,algo,
                          svmkernel = svmkernel, svmscale = svmscale,
                          adamfinal = adamfinal,
                          glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                          knnk =knnk,
                          pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                          nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                          nblap=nblap,
                          seed=seed)
      result[[algo]] = model$accuracy
    }
  }
  return(list("result"=result))
}
