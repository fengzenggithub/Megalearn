accuracy <-
function(trueLabel,predictedLabel){
  trueLabel <- as.vector(trueLabel)
  predictedLabel<-as.vector(predictedLabel)
  analyze <- predictedLabel == trueLabel
  accuracy <- length(analyze[analyze == TRUE])/length(trueLabel)
  return(accuracy)
}
