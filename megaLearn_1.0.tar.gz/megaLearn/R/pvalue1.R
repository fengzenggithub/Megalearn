pvalue1 <-
function(xtrain, ytrain){
  for(i in 1: dim(xtrain)[2]) {
    pvs[i]=fisher.test(table(xtrain[,i],ytrain))$p.v
  }
}
