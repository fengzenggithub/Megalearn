pvalue2 <-
function(xtrain, ytrain){
  for(i in 1: dim(xtrain)[2]) {
    pvs[i]= anova(lm(as.numeric(xtrain[,i])~factor(ytrain)))$Pr[1]
  }
}
