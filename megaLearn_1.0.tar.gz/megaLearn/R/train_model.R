train_model <-
function(xtrain,ytrain,xtest,ytest, algorithm = NULL,
                        rfntree, rfmtry = NULL,
                        svmkernel, svmscale,
                        adamfinal,
                        glmnetalpha, glmnetfamily, glmnetstandardize,
                        knnk,
                        pcatol, pcascale, pcacenter,
                        nnetsize, nnetrang, nnetdecay, nnetMaxNWts, nnetlinout, 
                        nblap,
                        seed=164000082)
{
  # CLEAN UP FROM PREVIOUS MODEL TRAINED
  gc()
  # CONDITIONAL TRAINING OF MODEL
  if (!is.null(seed)){
    set.seed(seed) 
  }
  #classifier 1: random forest
  if (algorithm=="Random Forest") {
    library(randomForest)
    model <- randomForest(x=xtrain, y=as.factor(ytrain))
    pre.label=predict(model,newdata=xtest)
    accur=accuracy(as.factor(ytest),pre.label)} 
  
  #classifier 2: SVM
  else if (algorithm=="SVM") {
    library(e1071)
    model <- svm(x=xtrain, y=as.factor(ytrain), kernel = svmkernel, scale = svmscale)
    pre.label=predict(model,newdata=xtest)
    accur=accuracy(as.factor(ytest),pre.label)} 
  
  #classifier 3: Ada boosing 
  else if (algorithm=="Ada boosting") {
    library(adabag)
    library(rpart)
    library(mlbench)
    library(caret)
    data=data.frame(xtrain,ytrain)
    model<-boosting(ytrain~.,data=data, mfinal = adamfinal)
    pre.label=predict(model,newdata=xtest)
    accur=accuracy(as.factor(ytest),pre.label$class)}
  
  #classifier 4: CART
  else if (algorithm=="CART") {
    library(rpart)
    data=data.frame(xtrain,ytrain)
    model <- rpart(ytrain ~., method="class", data=data)
    pre.label=predict(model, xtest,type = "class")
    accur=accuracy(as.factor(ytest),pre.label)} 
  
  #classifier 5: GLMNET
  else if (algorithm=="GLMNET") {
    library(glmnet)
    library(Matrix)
    library(foreach)
    library(slam)
    train_sparse <- sparse.model.matrix(~., xtrain)
    test_sparse <- sparse.model.matrix(~., xtest)
    
    cv <- cv.glmnet(train_sparse,as.factor(ytrain),family=glmnetfamily,nfolds=3, alpha = glmnetalpha, standardize = glmnetstandardize)
    model <- glmnet(train_sparse,as.factor(ytrain),family = glmnetfamily, standardize = glmnetstandardize, lambda = cv$lambda.min, alpha = glmnetalpha)
    pre.label <- predict(model, test_sparse, family = glmnetfamily, type="class")
    accur=accuracy(as.factor(ytest),pre.label)} 
  
  #classifier 6: KNN
  else if (algorithm=="KNN") {
    library(class)
    pre.label=knn(xtrain, xtest, ytrain, k = knnk)
    accur=accuracy(as.factor(ytest),pre.label)}
  
  #classifier 7: PCA-LDA
  else if (algorithm=="PCA-LDA") {
    library(MASS)
    princ_train <- prcomp(xtrain,center = pcacenter, scale.= pcascale, tol=0.2)
    pc_train=princ_train$x
    pc_train=data.frame(pc_train)
    numofpc=length(pc_train)
    
    model=lda(pc_train, ytrain)
    
    princ_test<-prcomp(xtest,center = FALSE, scale.= FALSE)
    pc_test=(princ_test$x)[,1:numofpc]
    pc_test=data.frame(pc_test)
    
    pre.label=predict(model,pc_test)
    accur=accuracy(as.factor(ytest),pre.label$class)}
  
  #classifier 8: nnet
  else if (algorithm=="NNET") {
    library(nnet)
    library(caret)
    set.seed(seed)
    data=data.frame(xtrain,ytrain)
    model <- nnet(ytrain~.,data=data,linout=nnetlinout,size=nnetsize,rang=nnetrang,decay=nnetdecay,MaxNWts=nnetMaxNWts)
    pre.label=predict(model, xtest, type = "class")
    accur=accuracy(ytest,pre.label)
  }
  
  else if (algorithm=="Naive Bayes"){
    library(e1071)
    model <- naiveBayes(as.matrix(xtrain),as.factor(ytrain),laplace=nblap)
    pre.label=predict(model,newdata=xtest,type="class")
    accur=accuracy(ytest,pre.label)
  }
  
  else {
    stop("ERROR: Invalid Classifier Specified")
  }
  
  gc() # CLEAN UP AFTER MODEL
  return(list("model"=model,"accuracy"=accur))
}
