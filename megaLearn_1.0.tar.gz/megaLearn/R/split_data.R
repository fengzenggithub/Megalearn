split_data <-
function(x,y,split_ratio,weight=NULL,seed=164000082){
  data=data.frame(x,y)
  nrow=nrow(data)
  ncol=ncol(data)
  if (!is.null(seed)){
    set.seed(seed) 
  }
  data=data[sample(1:nrow(data)),] #shuffle the data
  k=round(split_ratio*nrow(data))
  
  ytrain=data[-(1:k),ncol]
  ytest=data[(1:k),ncol]
  
  xtrain=data[-(1:k),1:(ncol-1)]
  xtest=data[(1:k),1:(ncol-1)]
  
  if (!is.null(weight)){
    xtrain=sweep(xtrain,2,weight,"*")
    xtest=sweep(xtest,2,weight,"*")
  }
  return(list("xtrain"=xtrain,"ytrain"=ytrain, "xtest"=xtest, "ytest"=ytest))
}
