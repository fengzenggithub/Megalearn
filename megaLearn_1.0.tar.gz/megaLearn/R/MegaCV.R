MegaCV <-
function(x,y, method = NULL,
                methodslist= NULL,
                nfold = 3,
                rfntree = 500, rfmtry = NULL,
                svmkernel = "linear", svmscale = FALSE,
                adamfinal = 100,
                glmnetalpha = 0.9, glmnetfamily = "multinomial", glmnetstandardize = FALSE,
                knnk = 1,
                pcatol = 0.2, pcascale = FALSE, pcacenter = FALSE,
                nnetsize = 5, nnetrang = 0.1, nnetdecay = 0.1, nnetMaxNWts = 5000, nnetlinout = FALSE, 
                nblap = 1,
                seed=164000082,
                weight=NULL){
  set.seed(seed)
  data=data.frame(x,y)
  nrow=dim(data)[1]
  ncol=dim(data)[2]
  
  rand=rep(1:nfold,length.out=nrow)
  rand=sample(rand) 

  modelResult=list()
  modelsResult=list()
  for (i in 1:nfold){
   x=data[,1:(ncol-1)]
   y=data[,ncol]
   
   ytrain=data[rand!=i,ncol]
   ytest=data[rand==i,ncol]
   
   xtrain=data[rand!=i,1:(ncol-1)]
   xtest=data[rand==i,1:(ncol-1)]
   
   if (!is.null(weight)){
     xtrain=sweep(xtrain,2,weight,"*")
     xtest=sweep(xtest,2,weight,"*")
   }
   
   acc = 0
  
   if(!is.null(method)){
     model=train_model(xtrain,ytrain,xtest,ytest,algorithm=method,
                       rfntree = rfntree, rfmtry = rfmtry,
                       svmkernel = svmkernel, svmscale = svmscale,
                       adamfinal = adamfinal,
                       glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                       knnk =knnk,
                       pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                       nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                       nblap=nblap,
                       seed=seed)
     acc = model$accuracy
     modelResult=cbind(modelResult,model$accuracy)
     df1<-as.vector(unlist(modelResult))
     method_mean_performance=mean(df1)
     names(method_mean_performance)=method
   }
   
   if(!is.null(methodslist)){
     models=train_models(xtrain,ytrain,xtest,ytest,methodslist=methodslist, acc = acc, method = method, 
                         rfntree = rfntree, rfmtry = rfmtry,
                         svmkernel = svmkernel, svmscale = svmscale,
                         adamfinal = adamfinal,
                         glmnetalpha = glmnetalpha, glmnetfamily =glmnetfamily, glmnetstandardize = glmnetstandardize,
                         knnk =knnk,
                         pcatol=pcatol, pcascale=pcascale, pcacenter=pcacenter,
                         nnetsize=nnetsize, nnetrang=nnetrang, nnetdecay=nnetdecay, nnetMaxNWts=nnetMaxNWts, nnetlinout=nnetlinout, 
                         nblap=nblap,
                         seed=seed)
     
     modelsResult=rbind(modelsResult,models$result)
     df2 <- matrix(unlist(modelsResult), ncol=ncol(modelsResult), 
                          dimnames=list(NULL, colnames(modelsResult)))
     methods_mean_performance=colMeans(df2)
     names(methods_mean_performance)=methodslist
   }
  }
  
  if (!is.null(method)&(!is.null(methodslist))){
    return(list("model" = model, "method_accuracy"=method_mean_performance,"methods_accuracy"=methods_mean_performance))
  }
  else if(is.null(method)&(!is.null(methodslist))){
    return(list("methods_accuracy"=methods_mean_performance))
  }
  else if(!is.null(method)&(is.null(methodslist))){
    return(list("model" = model,"method_accuracy"=method_mean_performance))
  }
  else{
    stop("Error: no classifier specified")
  }
}
